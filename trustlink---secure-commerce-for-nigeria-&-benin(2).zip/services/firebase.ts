
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";

// Ces variables doivent être définies dans votre environnement (ex: .env)
const firebaseConfig = {
  apiKey: process.env.VITE_FIREBASE_API_KEY || "VOTRE_API_KEY",
  authDomain: process.env.VITE_FIREBASE_AUTH_DOMAIN || "trustlink.firebaseapp.com",
  projectId: process.env.VITE_FIREBASE_PROJECT_ID || "trustlink",
  storageBucket: process.env.VITE_FIREBASE_STORAGE_BUCKET || "trustlink.appspot.com",
  messagingSenderId: process.env.VITE_FIREBASE_SENDER_ID || "0000000000",
  appId: process.env.VITE_FIREBASE_APP_ID || "1:0000000000:web:0000000000"
};

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
