
import { db } from './firebase';
import { collection, addDoc, getDocs, query, orderBy, Timestamp } from 'firebase/firestore';

export interface Lead {
  email: string;
  date: string;
  status: 'pending' | 'verified';
}

export const saveLead = async (email: string): Promise<boolean> => {
  try {
    // On ajoute le lead dans la collection "leads" de Firestore
    await addDoc(collection(db, "leads"), {
      email,
      date: Timestamp.now(),
      status: 'pending'
    });
    return true;
  } catch (error) {
    console.error("Erreur lors de l'enregistrement Firebase:", error);
    return false;
  }
};

export const getLeads = async (): Promise<Lead[]> => {
  try {
    const q = query(collection(db, "leads"), orderBy("date", "desc"));
    const querySnapshot = await getDocs(q);
    
    return querySnapshot.docs.map(doc => {
      const data = doc.data();
      return {
        email: data.email,
        // Conversion du Timestamp Firebase en string ISO
        date: data.date.toDate().toISOString(),
        status: data.status
      } as Lead;
    });
  } catch (error) {
    console.error("Erreur récupération leads:", error);
    return [];
  }
};

export const clearLeads = () => {
  // Optionnel: Dans Firebase, il vaut mieux supprimer les docs individuellement 
  // ou via une fonction Cloud. Pour la démo, on laisse vide car c'est dangereux.
  console.warn("ClearLeads n'est pas implémenté pour Firebase par sécurité.");
};
