
import React, { useState, useEffect } from 'react';
import { getLeads, Lead } from '../services/leads';

const AdminLeads: React.FC<{ onClose: () => void }> = ({ onClose }) => {
  const [leads, setLeads] = useState<Lead[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchLeads = async () => {
      setLoading(true);
      const data = await getLeads();
      setLeads(data);
      setLoading(false);
    };
    fetchLeads();
  }, []);

  return (
    <div className="fixed inset-0 z-[100] bg-slate-900/90 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[80vh]">
        <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-emerald-50">
          <div>
            <h2 className="text-xl font-bold text-slate-900">Base de données TrustLink</h2>
            <p className="text-sm text-slate-500">
              {loading ? 'Chargement...' : `${leads.length} prospect(s) en base (Firebase)`}
            </p>
          </div>
          <div className="flex gap-2">
            <button onClick={onClose} className="bg-slate-200 hover:bg-slate-300 p-2 rounded-full transition-colors">
              <i className="fas fa-times"></i>
            </button>
          </div>
        </div>
        
        <div className="flex-grow overflow-y-auto p-6">
          {loading ? (
            <div className="flex flex-col items-center justify-center py-20 text-emerald-600">
              <i className="fas fa-spinner animate-spin text-4xl mb-4"></i>
              <p className="text-slate-500">Connexion à Firestore...</p>
            </div>
          ) : leads.length === 0 ? (
            <div className="text-center py-12 text-slate-400">
              <i className="fas fa-user-slash text-4xl mb-4"></i>
              <p>Aucun email collecté dans Firebase.</p>
            </div>
          ) : (
            <table className="w-full text-left">
              <thead>
                <tr className="text-slate-400 text-sm uppercase tracking-wider">
                  <th className="pb-4 font-semibold">Email</th>
                  <th className="pb-4 font-semibold">Date d'inscription</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {leads.map((lead, i) => (
                  <tr key={i} className="hover:bg-slate-50 transition-colors">
                    <td className="py-4 font-medium text-slate-900">{lead.email}</td>
                    <td className="py-4 text-slate-500 text-sm">
                      {new Date(lead.date).toLocaleDateString('fr-FR', {
                        day: 'numeric',
                        month: 'long',
                        year: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit'
                      })}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
        
        <div className="p-6 bg-slate-50 border-t border-slate-100 text-center">
          <p className="text-xs text-slate-400 italic">
            Connecté à la collection "leads" en temps réel.
          </p>
        </div>
      </div>
    </div>
  );
};

export default AdminLeads;
